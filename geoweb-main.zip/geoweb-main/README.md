# geoweb
Mapas Módulo m2B

## Documentación 

[https://gis-master-m2.github.io/m2-geoweb/](https://gis-master-m2.github.io/m2-geoweb/)


## Para descargar los ejemplos 

[https://github.com/gis-master-m2/geoweb/archive/main.zip](https://github.com/gis-master-m2/geoweb/archive/main.zip)


## Para clonar proyecto con nombre diferente

```
git clone https://github.com/gis-master-m2/geoweb.git  geoweb-soluciones

```